# Primary and Secondary Region Deployment
In this example, the user would like to deploy prerequisite resources in both a primary and secondary (Disaster Recovery) AWS region in preparation for a "cold-standby" Disaster Recovery configuration with Terraform Enterprise.
<p>&nbsp;</p>

## Resources Provisioned

### Both Regions
* VPC
  * Public Subnets
  * Private Subnets
  * Internet Gateway
  * NAT Gateways (for each Public Subnet)
  * Route Tables and Routes
  * S3 VPC Endpoint
* Bastion host
* KMS Key
* AWS Secrets Manager secret

### Primary Region
* S3 "bootstrap" bucket in Primary region
* S3 Cross-Region Replication configuration between Primary and Replica buckets

### Secondary Region
* S3 "bootstrap" bucket **replica** in Secondary (Disaster Recovery) Region
<p>&nbsp;</p>

## Resources Omitted
N/A
<p>&nbsp;</p>

## Configuration
```hcl
#---------------------------------------------------------------------------
# Versions
#---------------------------------------------------------------------------
terraform {
  required_version = "~> 0.14.7"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 3.29.0"
    }
    template = {
      source  = "hashicorp/template"
      version = "~> 2.2.0"
  }
}

#---------------------------------------------------------------------------
# Locals
#---------------------------------------------------------------------------
locals {
  primary_region   = "us-east-1"
  secondary_region = "us-west-2"

  friendly_name_prefix = "winterfell"
  
  bootstrap_bucket_name_primary = "winterfell-tfe-bootstrap-primary-123456789"
  bootstrap_bucket_name_replica = "winterfell-tfe-bootstrap-replica-123456789"
}

#---------------------------------------------------------------------------
# Providers
#---------------------------------------------------------------------------
provider "aws" {
  region = local.primary_region
}

provider "aws" {
  alias  = "secondary"
  region = local.secondary_region
}

#---------------------------------------------------------------------------
# Primary Region
#---------------------------------------------------------------------------
module "tfe-prereqs-primary" {
  source = "github.com/hashicorp/is-terraform-aws-tfe-prereqs"

  # --- Common --- #
  friendly_name_prefix = local.friendly_name_prefix
  common_tags = {
    "Environment" = "tfe-prereq-primary"
    "Tool"        = "Terraform"
    "Owner"       = "NedStark"
  }

  # --- Network --- #
  deploy_vpc           = true
  vpc_cidr             = "10.0.0.0/16"
  public_subnet_cidrs  = ["10.0.1.0/24", "10.0.2.0/24", "10.0.3.0/24"]
  private_subnet_cidrs = ["10.0.255.0/24", "10.0.254.0/24", "10.0.253.0/24"]

  # --- Bastion --- #
  deploy_bastion             = true
  bastion_keypair            = "bastion-key-pair-us-east-1"
  bastion_ingress_cidr_allow = ["1.2.3.4/32"]

  # --- S3 Bucket Primary --- #
  deploy_bootstrap_bucket   = true
  bootstrap_bucket_name     = local.bootstrap_bucket_name_primary
  
  # --- S3 Bucket Replication --- #
  deploy_bucket_replication     = true
  bootstrap_bucket_name_replica = local.bootstrap_bucket_name_replica

  bucket_replication_configuration = {
    role = module.tfe-prereqs-primary.s3_replication_iam_role_arn

    rules = [
      {
        id       = "TFE"
        status   = "Enabled"

        destination = {
          bucket = "arn:aws:s3:::${module.tfe-prereqs-secondary.bootstrap_bucket_name}"
        }
      }
    ]
  }
}

output "vpc" {
  value = module.tfe-prereqs-primary.vpc_id
}

output "public_subnet_ids" {
  value = module.tfe-prereqs-primary.public_subnet_ids
}

output "private_subnet_ids" {
  value = module.tfe-prereqs-primary.private_subnet_ids
}

output "bastion_public_ip" {
  value = module.tfe-prereqs-primary.bastion_public_ip
}

output "bootstrap_bucket_name_primary" {
  value = module.tfe-prereqs-primary.bootstrap_bucket_name
}

#---------------------------------------------------------------------------
# Secondary Region
#---------------------------------------------------------------------------
module "tfe-prereqs-secondary" {
  source = "github.com/hashicorp/is-terraform-aws-tfe-prereqs"

  providers = {
    aws = aws.secondary
  }

  # --- Common --- #
  friendly_name_prefix = local.friendly_name_prefix
  common_tags = {
    "Environment" = "tfe-prereq-secondary"
    "Tool"        = "Terraform"
    "Owner"       = "NedStark"
  }

  # --- S3 Bucket Replica --- #
  deploy_bootstrap_bucket = true
  bootstrap_bucket_name   = local.bootstrap_bucket_name_replica
}

output "bootstrap_bucket_name_replica" {
  value = module.tfe-prereqs-secondary.bootstrap_bucket_name
}
```