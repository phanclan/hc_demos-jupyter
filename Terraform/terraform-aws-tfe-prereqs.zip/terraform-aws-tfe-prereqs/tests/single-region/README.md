# Single Region

In this example, the user only wants to provision resources in a single primary region.
<p>&nbsp;</p>

## Resources Provisioned

* VPC
  * Public Subnets
  * Private Subnets
  * Internet Gateway
  * NAT Gateways (for each Public Subnet)
  * Route Tables and Routes
  * S3 VPC Endpoint
* Bastion host
* S3 "bootstrap" bucket (Primary)
* KMS Key
* AWS Secrets Manager secret
* AWS CloudWatch Log Group

<p>&nbsp;</p>

## Resources Omitted

* S3 "bootstrap" bucket **replica** in Secondary (Disaster Recovery) region
* S3 Cross-Region Replication (CRR) configuration between 'Primary' and 'Replica' buckets
* S3 "logging" bucket

<p>&nbsp;</p>
