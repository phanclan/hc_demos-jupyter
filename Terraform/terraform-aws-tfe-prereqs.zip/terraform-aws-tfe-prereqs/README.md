# TFE on AWS Prerequisites

This Terraform module is intended to assist with the provisioning of prerequisite resources potentially needed for a TFE on AWS deployment. Every environment is different, and this may not be all-encompassing for all users' requirements; however this module includes most of the core resources that are necessary in common deployment scenarios. All of the resource type categories are optional, so certain components can be omitted if desired. See the [examples](##Examples) section below for further details.
<p>&nbsp;</p>

## Requirements

- Terraform >= 0.14.x
- AWS account

## Usage

By default, all of the boolean input variables are set to `false`. Opt in to deploying each resource of choice by setting the boolean input variables to `true`.

### Examples

- [Single Region](./examples/single-region/README.md)
- [Primary Region w/ Replica Bucket in Secondary Region](./examples/primary-with-s3-crr/README.md)
- [Primary Region and Secondary (Disaster Recovery) Region](./examples/primary-and-secondary-region/README.md)

## Resources and Use Case

### TFE Networking

* VPC
- Public Subnet(s)
- Private Subnet(s)
- Internet Gateway
- Elastic IP(s)**
- NAT Gateway(s)**
- Public Route Table
- Public Route
- Public Route Table Association(s)
- Private Route Table(s)
- Private Route(s)
- Private Route Table Association(s)
- S3 VPC Endpoint
- Public S3 VPC Endpoint Route Table Association(s)
- Private S3 VPC Endpoint Route Table Association(s)

### TFE EC2 Instance - Shell Access

* Bastion EC2 Instance
- Bastion Security Group
- Bastion Security Group Rules
- SSH Key Pair

### Encryption (RDS, S3, & EBS)

* KMS Key
- KMS Key Alias

### Secrets Management

* AWS Secrets Manager Secret Metadata
- AWS Secrets Manager Secret(s)

### S3 "Bootstrap" Bucket

* S3 "bootstrap" bucket (details in section below)

#### S3 "Bootstrap" Bucket Description

The first S3 bucket included in this module is typically a key prerequisite resource in a production Terraform Enterprise deployment. It is referred to as the "bootstrap" bucket because it can contain objects pertaining to the actual installation the TFE application. The TFE applciation EC2 instance is granted access to this bucket to retrieve the files from within the `user_data` script prior to installation.  Here are the use cases:
- stage TFE license file (`tfe-license.rli`)
- stage TFE airgap bundle and `replicated.tar.gz` tarball (if customer deployment is airgapped)
- configure a "replica" bucket leveraging S3 Cross-Region Replication (CRR) in another region for extra backup and/or Disaster Recovery purposes

### S3 "Logging" Bucket

* S3 "logging" bucket (details in section below)

#### S3 "Logging" Bucket Description

The second S3 bucket included in this module can be used as a log destination for TFE. This bucket is not created with the TFE deployment, so the lifecycle of the logging bucket is not tied to the deployment of TFE. If this bucket is created, it will use the KMS key for setting default encryption. This bucket should only be used for logging and not as the "bootstrap" bucket. Versioning can be enabled with the variable `logging_bucket_versioning_enabled` With a the variable `logging_bucket_lifecycle_enabled` and variable `logging_bucket_lifecycle_expiration_days` a lifecycle can be configured to remove files after a set number of days.

### CloudWatch Logs

* CloudWatch Logs (details in section below)

#### CloudWatch Logs Description

This module also supports logging to a CloudWatch Log Group. If the variable `deploy_log_group` is configured along with variable `log_group_name` new CloudWatch Log Group will be created. Using the variable `log_group_retention_days` the number of days the logs are retained can be configured. Note: there is a list of days that can be configured not any number.

<p>&nbsp;</p>

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| bastion\_ingress\_cidr\_allow | List of CIDR ranges to allow SSH ingress to Bastion instance. | `list(string)` | `[]` | no |
| bastion\_keypair | Existing SSH key pair to use for bastion instance. | `string` | `null` | no |
| bootstrap\_bucket\_name | Name of S3 bootstrap bucket for primary region. | `string` | `null` | no |
| bootstrap\_bucket\_name\_replica | Name of S3 bootstrap replica bucket in secondary (destination) region. Required if `deploy_bucket_replication` is `true`. | `string` | `null` | no |
| bucket\_replication\_configuration | Map containing S3 Cross-Region Replication configuration. If a value is specified, `bootstrap_bucket_name_replica` is required. | `any` | `{}` | no |
| common\_tags | Map of common tags for all taggable AWS resources. | `map(string)` | `{}` | no |
| deploy\_bastion | Boolean to deploy a bastion instance. Only specify `true` if `deploy_vpc` is also `true`. | `bool` | `false` | no |
| deploy\_bootstrap\_bucket | Boolean to deploy an S3 bootstrap bucket in the primary region. | `bool` | `false` | no |
| deploy\_bucket\_replication | Boolean to configure S3 Cross-Region Replication against an S3 replica bucket. A 'Secondary' replica bucket is required (`bootstrap_bucket_name_replica`). | `bool` | `false` | no |
| deploy\_kms | Boolean to deploy AWS KMS CMK Key. | `bool` | `false` | no |
| deploy\_log\_group | Boolean to deploy a Cloud Watch Log Group to be used for TFE Logs. | `bool` | `false` | no |
| deploy\_logging\_bucket | Boolean to deploy an S3 bucket to be used for TFE Logs. | `bool` | `false` | no |
| deploy\_secretsmanager | Boolean to deploy AWS Secrets Manager secret. | `bool` | `false` | no |
| deploy\_tfe\_keypair | Boolean to deploy TFE SSH key pair. This is separate from the `bastion_keypair`. | `bool` | `false` | no |
| deploy\_vpc | Boolean to deploy a VPC. | `bool` | `false` | no |
| friendly\_name\_prefix | Friendly name prefix used for tagging and naming AWS resources. | `string` | n/a | yes |
| kms\_allow\_asg\_to\_cmk | Boolen to create a KMS CMK Key policy that grants the Service Linked Role AWSServiceRoleForAutoScaling permissions to the CMK. | `bool` | `true` | no |
| kms\_key\_alias | KMS Key Alias for CMK Key. | `string` | `null` | no |
| kms\_key\_deletion\_window | Duration in days to destroy the key after it is deleted. Must be between 7 and 30 days. | `number` | `7` | no |
| log\_group\_name | Name of the Cloud Watch Log Group to be used for TFE Logs. | `string` | `null` | no |
| log\_group\_retention\_days | Number of days to retain logs in Log Group. | `number` | `30` | no |
| logging\_bucket\_lifecycle\_enabled | Boolean to control if the S3 lifecycle policy is enabled on the logging bucket. | `bool` | `false` | no |
| logging\_bucket\_lifecycle\_expiration\_days | Number of days to retain logs in logging bucket if `logging_bucket_versioning_enabled` is enabled. | `number` | `null` | no |
| logging\_bucket\_name | Name of the AWS S3 bucket to be used for TFE Logs. | `string` | `null` | no |
| logging\_bucket\_versioning\_enabled | Boolean to control if the S3 lifecycle policy is enabled on the logging bucket. | `bool` | `false` | no |
| private\_subnet\_cidrs | List of private subnet CIDR ranges to create in VPC. | `list(string)` | `[]` | no |
| public\_subnet\_cidrs | List of public subnet CIDR ranges to create in VPC. | `list(string)` | `[]` | no |
| secretsmanager\_secret\_name | Name of AWS Secrets Manager secret metadata. This value will be auto-generated if left unspecified and `deploy_secretsmanager` is `true`. | `string` | `null` | no |
| secretsmanager\_secrets | Map of key/value pairs of TFE install secrets. | `map(string)` | `{}` | no |
| tfe\_ssh\_public\_key | Public key material for TFE SSH Key Pair. | `string` | `null` | no |
| vpc\_cidr | CIDR block for VPC. | `string` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| bastion\_private\_ip | Private IP of bastion instance. |
| bastion\_public\_dns | Public DNS name of bastion instance. |
| bastion\_public\_ip | Public IP of bastion instance. |
| bootstrap\_bucket\_arn | ARN of S3 bootstrap bucket |
| bootstrap\_bucket\_name | Name of S3 bootstrap bucket. |
| kms\_key\_arn | KMS CMK Key ARN. |
| kms\_key\_id | KMS CMK Key ID. |
| log\_bucket\_name | Name of the s3 log bucket. |
| log\_group\_name | AWS CloudWatch Log Group Name. |
| private\_subnet\_ids | Subnet IDs of private subnets. |
| public\_subnet\_ids | Subnet IDs of public subnets. |
| s3\_replication\_iam\_role\_arn | ARN of IAM Role for S3 replication. |
| secretsmanager\_secret\_arn | AWS Secrets Manager secret ARN. |
| tfe\_ssh\_keypair\_fingerprint | Fingerprint of TFE SSH Key Pair. |
| tfe\_ssh\_keypair\_id | ID of TFE SSH Key Pair. |
| tfe\_ssh\_keypair\_name | Name of TFE SSH Key Pair. |
| vpc\_id | VPC ID. |
